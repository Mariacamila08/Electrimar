<?php

/*Constantes para la conexión a la base de datos
"define" especifica que es una constante,
el primer parámetro sera el nombre de la constante, 
el segundo el valor de la constante (key value)
*/


define ('DB_HOST', 'localhost');
define ('DB_DATABASE', 'proyectoelectrimar');
define ('DB_USER', 'root');
define ('DB_PASSWORD', '');

?>