<?php
	include_once ('utilidades.inc');
	$_SESSION=[];
	header('location:../index.php');

?>