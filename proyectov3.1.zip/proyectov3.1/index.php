<?php
/* Para incluir librerías de base de datos y utilidades */
include_once ("db/utilidades_sql.php");
include_once ("php/utilidades.inc");
?>



		
			<?php include_once('php/header.inc'); ?>
							
							


			<?php 
			include_once('php/footer.inc')
			?>
	